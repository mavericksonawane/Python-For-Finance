
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
from pandas_datareader import data as wb
import matplotlib.pyplot as plt
from scipy.stats import norm
get_ipython().run_line_magic('matplotlib', 'inline')
#it facilitates plotting matplotlib graphs just below code and storing them in the notebook document


# In[2]:


ticker = 'AAPL'
data = pd.DataFrame()
data[ticker] = wb.DataReader(ticker, data_source='yahoo', start='2003-1-1')['Adj Close']


# In[3]:


log_returns = np.log(1 + data.pct_change())
#pandas.pct_change() ~ percentage change
#It obtains simple returns from a provided dataset


# In[4]:


log_returns.head()


# In[5]:


log_returns.tail()


# In[6]:


data.plot(figsize=(10, 6));


# In[7]:


log_returns.plot(figsize=(10, 6))


# In[8]:


u = log_returns.mean()
u


# In[9]:


var = log_returns.var()
var


# In[10]:


drift = u - (0.5 * var)
drift


# In[11]:


stdev = log_returns.std()
stdev


# In[12]:


type(drift)


# In[13]:


type(stdev)


# In[14]:


np.array(drift)


# In[15]:


drift.values #transfers the object into a numpy array


# In[16]:


stdev.values


# In[17]:


norm.ppf(0.95)


# In[18]:


x = np.random.rand(10, 2)
x


# In[19]:


norm.ppf(x)


# In[20]:


Z = norm.ppf(np.random.rand(10 , 2))
Z


# Z corresponds to the distance between the mean and the events,
# expressed as the number of std deviations

# In[21]:


t_intervals = 1000
iterations = 10


# In[22]:


daily_returns = np.exp(drift.values + stdev.values * norm.ppf(np.random.rand(t_intervals, iterations)))


# In[23]:


daily_returns


# In[24]:


S0 = data.iloc[-1]


# In[25]:


S0


# In[27]:


price_list = np.zeros_like(daily_returns)
price_list


# _We printed these 0s to replace them with expected stock prices by using a loop_

# In[29]:


price_list[0] = S0
price_list


# In[30]:


for t in range(1, t_intervals):
    price_list[t] = price_list[t - 1] * daily_returns[t]


# In[31]:


price_list


# In[32]:


plt.figure(figsize=(10,6))
plt.plot(price_list);

