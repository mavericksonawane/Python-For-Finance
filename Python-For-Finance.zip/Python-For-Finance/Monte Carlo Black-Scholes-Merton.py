
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
from pandas_datareader import data as wb
from scipy.stats import norm


# In[2]:


def d1(S, K, r, stdev, T):
    return (np.log(S / K) + (r + stdev ** 2 / 2) * T) / (stdev * np.sqrt(T))

def d2(S, K, r, stdev, T):
    return (np.log(S / K) + (r + stdev ** 2 / 2) * T) / (stdev * np.sqrt(T))


# In[3]:


norm.cdf(0) #cumulative Distribution Function


# In[4]:


norm.cdf(0.25)


# In[9]:


norm.cdf(0.75)


# In[8]:


norm.cdf(9)

