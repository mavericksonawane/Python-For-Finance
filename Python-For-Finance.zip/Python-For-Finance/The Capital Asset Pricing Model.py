
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
from pandas_datareader import data as wb
tickers = ['PG', '^GSPC']
data = pd.DataFrame()
for t in tickers:
    data[t] = wb.DataReader(t, data_source='yahoo', start='2010-1-1',end='2017-12-31')['Adj Close']


# In[2]:


sec_returns = np.log(data / data.shift(1))


# In[3]:


cov = sec_returns.cov() * 250
cov


# In[4]:


cov_with_market = cov.iloc[0,1]
cov_with_market


# In[5]:


market_var = sec_returns['^GSPC'].var() * 250
market_var


# In[6]:


PG_beta = cov_with_market / market_var
PG_beta


# _**Calculating the expected return of P&G (CAPM)**_ :

# In[7]:


PG_er = 0.025 + PG_beta * 0.05
PG_er


# _**Sharpe Ratio**_ :

# In[8]:


Sharpe = (PG_er - 0.025) / (sec_returns['PG'].std() * 250 ** 0.5)
Sharpe

