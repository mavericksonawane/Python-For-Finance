
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
from pandas_datareader import data as wb
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')
#it facilitates plotting matplotlib graphs just below code and storing them in the notebook document


# In[2]:


assets = ['PG','^GSPC']
pf_data = pd.DataFrame()

for a in assets:
    pf_data[a] = wb.DataReader(a, data_source = 'yahoo', start = '2005-1-1')['Adj Close']


# In[3]:


pf_data.tail()


# In[4]:


(pf_data / pf_data.iloc[0] * 100).plot(figsize=(10, 5))


# In[5]:


log_returns = np.log(pf_data / pf_data.shift(1))


# In[6]:


log_returns.mean() * 250


# In[7]:


log_returns.cov() * 250


# In[8]:


log_returns.corr() * 250


# In[9]:


num_assets = len(assets)
num_assets


# In[10]:


weights = np.random.random(num_assets)
weights /= np.sum(weights)
weights


# In[11]:


weights[0] + weights[1]


# _**Expected portfolio Return**_ :

# In[12]:


np.sum(weights * log_returns.mean()) * 250


# _**Expected Portfolio Variance**_ :

# In[13]:


np.dot(weights.T,np.dot(log_returns.cov() * 250, weights))


# _**Expected Portfolio Volatility**_ :

# In[14]:


np.sqrt(np.dot(weights.T,np.dot(log_returns.cov() * 250,weights)))


# **Note**: _I'm not considering 1,000 different investments_! <br>
# _I'm considering 1,000 different **combinations** of the Two Same assets!_

# In[15]:


pfolio_returns = []
pfolio_volatilities = []

for x in range (1000):
    weights = np.random.random(num_assets)
    weights /= np.sum(weights)
    pfolio_returns.append(np.sum(weights * log_returns.mean()) * 250)
    pfolio_volatilities.append(np.sqrt(np.dot(weights.T,np.dot(log_returns.cov() * 250,weights))))
    
pfolio_returns, pfolio_volatilities    


# In[16]:


pfolio_returns = []
pfolio_volatilities = []

for x in range (1000):
    weights = np.random.random(num_assets)
    weights /= np.sum(weights)
    pfolio_returns.append(np.sum(weights * log_returns.mean()) * 250)
    pfolio_volatilities.append(np.sqrt(np.dot(weights.T,np.dot(log_returns.cov() * 250, weights))))
    
pfolio_returns = np.array(pfolio_returns)
pfolio_volatilities = np.array(pfolio_volatilities)

pfolio_returns, pfolio_volatilities


# In[17]:


portfolios = pd.DataFrame({'Return': pfolio_returns, 'volatility': pfolio_volatilities})


# In[18]:


portfolios.head()


# In[19]:


portfolios.tail()


# In[20]:


portfolios.plot(x='volatility', y='Return', kind='scatter', figsize=(10,6));
plt.xlabel('Expected volatility')
plt.ylabel('Expected Return')


# VERY COOL :)
