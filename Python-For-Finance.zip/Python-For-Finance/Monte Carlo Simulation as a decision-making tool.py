
# coding: utf-8

# # Monte Carlo Predicting Gross Profit

# In[1]:


import numpy as np
import matplotlib.pyplot as plt


# In[2]:


rev_m = 170 #Revenue Mean
rev_stdev = 20 #Revenue Std.Deviation
iterations = 1000


# In[3]:


rev = np.random.normal(rev_m, rev_stdev, iterations)
rev


# In[4]:


plt.figure(figsize=(15, 6))
plt.plot(rev)
plt.show()


# In[5]:


COGS = - (rev * np.random.normal(0.6,0.1)) #Cost Of Goods Sold, COGS = 60% of the revenues
plt.figure(figsize=(15, 6))
plt.plot(COGS)
plt.show()


# In[6]:


COGS.mean()


# In[7]:


COGS.std()


# In[8]:


Gross_Profit = rev + COGS
Gross_Profit


# In[9]:


plt.figure(figsize=(15, 6))
plt.plot(Gross_Profit)
plt.show()


# In[10]:


max(Gross_Profit)


# In[11]:


min(Gross_Profit)


# In[12]:


Gross_Profit.mean()


# In[13]:


Gross_Profit.std()


# In[14]:


plt.figure(figsize=(10, 6));
plt.hist(Gross_Profit, bins = [40, 50, 60, 70, 80, 90, 100, 110, 120]);
#bins = split data in different intervals
plt.show()


# In[15]:


plt.figure(figsize=(10, 6));
plt.hist(Gross_Profit, bins = 20); 
plt.show()

