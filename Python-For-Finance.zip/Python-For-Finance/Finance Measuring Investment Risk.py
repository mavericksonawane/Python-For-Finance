
# coding: utf-8

# # "Finance Measuring Investment Risk"

# # Calculating a security's Risk In Python :

# In[1]:


import numpy as np
import pandas as pd
from pandas_datareader import data as wb
import matplotlib.pyplot as plt


# In[2]:


tickers = ['AAPL', 'MSFT']
sec_data = pd.DataFrame()

for t in tickers:
    sec_data[t] = wb.DataReader(t, data_source='yahoo', start='2005-1-1')['Adj Close']


# In[3]:


sec_data.head()


# In[4]:


sec_data.tail()


# In[5]:


sec_returns = np.log(sec_data / sec_data.shift(1)) #log returns
sec_returns


# # AAPL :

# In[6]:


sec_returns['AAPL'].mean()


# In[7]:


sec_returns['AAPL'].mean() * 250


# In[8]:


sec_returns['AAPL'].std() #standard deviation


# In[9]:


sec_returns['AAPL'].std() * 250 ** 0.5 #raise to the power of 0.5


# # MSFT :

# In[10]:


sec_returns['MSFT'].mean()


# In[11]:


sec_returns['MSFT'].mean() * 250


# In[12]:


sec_returns['MSFT'].std() #standard deviation


# In[13]:


sec_returns['MSFT'].std() * 250 ** 0.5 #raise to the power of 0.5


# In[14]:


sec_returns[['AAPL', 'MSFT']].mean() * 250


# In[15]:


sec_returns[['AAPL', 'MSFT']].std() * 250 ** 0.5


# In[16]:


(sec_data / sec_data.iloc[0] * 100).plot(figsize=(15, 6));
plt.show()


# WINNER : ""AAPL""

# # Covariance and Correlation :

# In[17]:


AP_var = sec_returns['AAPL'].var() #calculates variance
AP_var


# In[18]:


MS_var = sec_returns['MSFT'].var() #calculates variance
MS_var


# In[19]:


AP_var_a = sec_returns['AAPL'].var() * 250
AP_var_a


# In[20]:


MS_var_a = sec_returns['MSFT'].var() * 250
MS_var_a


# In[21]:


cov_matrix = sec_returns.cov() #computes pairwise covariance of columns
cov_matrix


# In[22]:


cov_matrix = sec_returns.cov() * 250
cov_matrix


# In[23]:


corr_matrix = sec_returns.corr() #computes pairwise correlation of columns
corr_matrix 

# The values in the diagonals are same. Why?
--> Because the Stock returns between two companies are correlated.
*NOTE: This is NOT the correlation between the price of the two equities!
# # Calculating Portfolio Risk :

# Equal weighting Scheme:

# In[24]:


weights = np.array([0.5, 0.5])


# Portfolio Volatility:

# In[25]:


pfolio_vol = (np.dot(weights.T, np.dot(sec_returns.cov() * 250, weights))) ** 0.5
pfolio_vol


# Portfolio Variance:

# In[26]:


pfolio_var = np.dot(weights.T, np.dot(sec_returns.cov() * 250, weights))
pfolio_var


# In[27]:


print (str(round(pfolio_vol, 5) * 100) + '%')


# # Calculating Diversifiable and Non-Diversifiable Risk of a Portfolio :

# _Diversifiable Risk:_

# In[28]:


AP_var_a = sec_returns[['AAPL']].var() * 250
AP_var_a


# In[29]:


MS_var_a = sec_returns[['MSFT']].var() * 250
MS_var_a


# In[30]:


dr = pfolio_var - (weights[0] ** 2 * AP_var_a) - (weights[1] ** 2 * MS_var_a)
dr
float(AP_var_a)


# In[31]:


AP_var_a = sec_returns['AAPL'].var() * 250
AP_var_a


# In[32]:


MS_var_a = sec_returns['MSFT'].var() * 250
MS_var_a


# In[33]:


dr = pfolio_var - (weights[0] ** 2 * AP_var_a) - (weights[1] ** 2 * MS_var_a)
dr


# In[34]:


print (str(round(dr*100, 3)) + '%')


# _Non-Diversifiable Risk:_

# In[35]:


ndr_1 = pfolio_var - dr
ndr_1


# In[36]:


ndr_2 = (weights[0] ** 2 * AP_var_a) + (weights[1] ** 2 * MS_var_a)
ndr_2


# In[37]:


ndr_1 == ndr_2

